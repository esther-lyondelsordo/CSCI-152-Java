package LoDiceList;

import java.util.Objects;

public class CircularLList {
    Player head;

    //constructors
    public CircularLList() {
        head = null;
    }

    public void insertPlayer(int playerNumber, String Name, int totalScore, int currentScore, int winnings, int round) {
        //new node with value to add to list
        head = null;
        Player newPlayer;
        newPlayer = new Player(playerNumber, Name, totalScore, currentScore, winnings, round);

        //new node for traversals
        Player curr;

        //inserting into empty list
        if (head == null) {
            System.out.println("Inserting into empty Circular list");
            head = newPlayer;
        }
        //head.next = newNode;

        // insert at end of list
        else  {
            curr = head;

            System.out.println("Insert at end of Circular list");

            while ((curr.next != head)&&(curr.next != null)) {
                curr = curr.next;
            }
            curr.next  = newPlayer;
            newPlayer.next = head;

        }
    } //end insertPlayer

    public void printList() {
        int i = 0;
        Player curr = head;
        do {
            System.out.println("Player " + ++i + " Name: " + curr.Name + " Score: " + curr.totalScore +
                    "Rounds played: " + curr.round + " Money won: " + curr.winnings);
            curr = curr.next;
        } while(curr != head);

    } //end printList

    //make dice
    int die1;
    int die2;
    int die3;
    //method to roll dice
    public void roll() {
        // Roll the dice by setting each of the dice to be
        // a random number between 1 and 6.
        die1 = (int)(Math.random()*6) + 1;
        die2 = (int)(Math.random()*6) + 1;
        die3 = (int)(Math.random()*6) + 1;
    }

    public void playRound() {
        Player current = head, index;

        //traverse players, roll 3 dice until scoring possible and add points to currentScore
        do {
            //Index will point to node next to current
            index = current.next;
            while (index != head) {
                // roll until score is valid
                boolean stop = false;
                while(!stop) {
                    roll();
                    if ((die1 == 1)&&(die2 == 1)&&(die3 == 1)) {
                        current.currentScore += 7;
                        stop = true;
                    }
                    else if ((die1 == 2)&&(die2 == 2)&&(die3 == 2)) {
                        current.currentScore += 8;
                        stop = true;
                    }
                    else if ((die1 == 3)&&(die2 == 3)&&(die3 == 3)) {
                        current.currentScore += 9;
                        stop = true;
                    }
                    else if ((die1 == 4)&&(die2 == 4)&&(die3 == 4)) {
                        current.currentScore += 10;
                        stop = true;
                    }
                    else if ((die1 == 5)&&(die2 == 5)&&(die3 == 5)) {
                        current.currentScore += 11;
                        stop = true;
                    }
                    else if ((die1 == 6)&&(die2 == 6)&&(die3 == 6)) {
                        current.currentScore += 12;
                        stop = true;
                    }
                    else if (((Objects.equals(die1, die2))&&(die3 == 1))||((Objects.equals(die2, die3))&&(die1 == 1))||
                            ((Objects.equals(die1, die3))&&(die2 == 1))) {
                        current.currentScore += 1;
                        stop = true;
                    }
                    else if (((Objects.equals(die1, die2))&&(die3 == 2))||((Objects.equals(die2, die3))&&(die1 == 2))||
                            ((Objects.equals(die1, die3))&&(die2 == 2))) {
                        current.currentScore += 2;
                        stop = true;
                    }
                    else if (((Objects.equals(die1, die2))&&(die3 == 3))||((Objects.equals(die2, die3))&&(die1 == 3))||
                            ((Objects.equals(die1, die3))&&(die2 == 3))) {
                        current.currentScore += 3;
                        stop = true;
                    }
                    else if (((Objects.equals(die1, die2))&&(die3 == 4))||((Objects.equals(die2, die3))&&(die1 == 4))||
                            ((Objects.equals(die1, die3))&&(die2 == 4))) {
                        current.currentScore += 4;
                        stop = true;
                    }
                    else if (((Objects.equals(die1, die2))&&(die3 == 5))||((Objects.equals(die2, die3))&&(die1 == 5))||
                            ((Objects.equals(die1, die3))&&(die2 == 5))) {
                        current.currentScore += 5;
                        stop = true;
                    }
                    else if (((Objects.equals(die1, die2))&&(die3 == 6))||((Objects.equals(die2, die3))&&(die1 == 6))||
                            ((Objects.equals(die1, die3))&&(die2 == 6))) {
                        current.currentScore += 6;
                        stop = true;
                    }
                    else if (((die1 == 4)&&(die2 == 5)&&(die3 == 6))||((die1 == 4)&&(die2 == 6)&&(die3 == 5))||
                            ((die1 == 5)&&(die2 == 4)&&(die3 == 6))||((die1 == 5)&&(die2 == 6)&&(die3 == 4))||
                            ((die1 == 6)&&(die2 == 4)&&(die3 == 5))||((die1 == 6)&&(die2 == 5)&&(die3 == 4))) {
                        current.currentScore += 13;
                        stop = true;
                    }
                    else if (((die1 == 1)&&(die2 == 2)&&(die3 == 3))||((die1 == 1)&&(die2 == 3)&&(die3 == 2))||
                            ((die1 == 2)&&(die2 == 1)&&(die3 == 3))||((die1 == 2)&&(die2 == 3)&&(die3 == 1))||
                            ((die1 == 3)&&(die2 == 1)&&(die3 == 2))||((die1 == 3)&&(die2 == 2)&&(die3 == 1))) {
                        current.currentScore += 0;
                        stop = true;
                    }
                    else {
                        stop = false;
                    }
                }
                //call checkForTies after each player gets a valid roll
                checkForTies();
                index = index.next;
            }
            current = current.next;
        }while (current.next != head);

    } // end playRound

    // make a circular list for tied players
    CircularLList tiedPlayers;

    public void checkForTies() {
        //sort list so all ties are next to each other
        sortList();
        //traverse list to see if any of the current Scores are equal
        int numTies = 0;
        Player current = head, index;
        do {
            //Index will point to node next to current
            index = current.next;
            while (index != head) {
                //If if the scores of current and the one after are equal,
                // shallow copy the players to tiedPlayers, increment numTies
                if (Objects.equals(current.currentScore, index.currentScore)) {
                    tiedPlayers.insertPlayer(current.playerNumber, current.Name, current.totalScore,
                                current.currentScore, current.winnings, current.round);
                    tiedPlayers.insertPlayer(index.playerNumber, index.Name, index.totalScore,
                                index.currentScore, index.winnings, index.round);
                    numTies++;
                }
                index = index.next;
            }
            current = current.next;
        }while (current.next != head);

        //if tiedPlayers is not empty, call playTieRound
        if (numTies != 0) {
            tiedPlayers.playTieRound();
        }

    }

    public void playTieRound() {
        playRound();

    } // end playTieRound

    // method to sort the list by descending order of total score
    public void sortList() {
        Player current = head, index;
        int temp;
        if (head == null) {
            System.out.println("List is empty");
        }
        else {
            do {
                //Index will point to node next to current
                index = current.next;
                while (index != head) {
                    //If current node is less than index data, swaps the data
                    if (current.totalScore < index.totalScore) {
                        temp = current.totalScore;
                        current.totalScore = index.totalScore;
                        index.totalScore = temp;
                    }
                    index = index.next;
                }
                current = current.next;
            }while (current.next != head);
        }
    } // end sortList


} //end CircularLList

