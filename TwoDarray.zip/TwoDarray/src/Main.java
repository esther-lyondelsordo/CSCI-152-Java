public class Main {

    public static void main(String[] args) {
        int [][] intArray = new int[100][];

        for (int i = 0; i < intArray.length; i++) {
            int r = i * 2;
            intArray[i] = new int[r];
        }

        for (int i = 0; i < intArray.length; ++i) {
            for(int j = 0; j < intArray[i].length; ++j) {
                intArray[i][j] = i;
            }
        }

        for (int i = 0; i < intArray.length; ++i) {
            for(int j = 0; j < intArray[i].length; ++j) {
                System.out.print(intArray[i][j]);
            }
            System.out.println();
        }
    }
}
