package introOOP;

public class Zombie extends Character {
    // constructors
    //method to check the nearest neighbors of a given cell, then move "out"
//        int row = 0, col = 0;
//        int numIterations = 1;
//
//        //int maxIterations = calculateNumIterations(sRow, sCol);
//        int maxIterations = matrix.length - 1;  // can be changed for efficiency
//
//        matrix[x][y] = 'Z';    // these two lines are not necessary for logic but
//        outputWorld(matrix);   // print the Patient Zero matrix
//
//        while (numIterations <= maxIterations) {
//            for (row = x - numIterations; row <= x + numIterations; row++) {
//                for (col = y - numIterations; col <= y + numIterations; col++) {
//                    try {
//                        matrix[row][col] = 'Z';
//                    }
//                    catch (IndexOutOfBoundsException ex) {
//                        //do nothing, just keep running
//                        //this method, as written, goes out of bounds a lot
//                    }
//                }
//            }
//            numIterations++;
//            outputWorld(matrix);
//        }
    // setters
    // getters
}
