// Zombie OOP
package introOOP;

public class ZombieDriver {

    public static void main(String[] args) {
        /* create and modify objects in here for printing */
        
    }
}

// MONSTER OOP
//package introOOP;
//
//class Monster  {
//    boolean scary = true;
//    String monsterType = "nocturnal";
//
//    // setters
//    public void setScary(boolean newValue)  {
//        this.scary = newValue;
//    }
//
//    public void setMonsterType(String newType) {
//        this.monsterType = newType;
//    }
//
//    //getters
//    public boolean isScary()  {
//        return this.scary;
//    }
//
//    public String getMonsterType()  {
//        return this.monsterType;
//    }
//}
//
//class Vampire extends Monster {
//    private boolean hungry = true;
//
//    //Constructors
//    Vampire() {
//        this.monsterType = "biting";
//        System.out.println("A vampire was created.");
//    }
//
//    // write setters and getters
//    public boolean isHungry() {
//        return hungry;
//    }
//
//    public void setHungry(boolean hungry) {
//        this.hungry = hungry;
//    }
//
//}
//
//class Werewolf extends Monster {
//
//    private boolean fullmoon = true;
//
//    Werewolf() {
//        this.monsterType = "biting";
//        System.out.println("A werewolf was created.");
//    }
//
//    public boolean isFullmoon() {
//        return fullmoon;
//    }
//
//    public void setFullmoon(boolean fullmoon) {
//        this.fullmoon = fullmoon;
//    }
//
//}
//
//public class MonsterDriver {
//
//    public static void main(String[] args) {
//        Vampire v = new Vampire();
//        v.setMonsterType("Very scary vampire");
//        System.out.println(v.getMonsterType());
//
//        // create objects of each type, test all getters and setters
//        Werewolf w = new Werewolf();
//        w.setMonsterType("Very scary werewolf");
//        System.out.println(w.getMonsterType());
//
//        // create an array of monsters
//        Monster[] m = new Monster[10];
//
//        // instantiate each array object with a monster type
//        for (int i = 0; i < m.length; i++){
//            if (i % 2 == 0) {
//                m[i] = new Vampire();
//            }
//            else {
//                m[i] = new Werewolf();
//            }
//        }
//
//        // change some attributes of the array objects with setters
//        m[0].setMonsterType("hairy");
//        m[1].setMonsterType("ominous");
//        m[4].setMonsterType("mangy");
//        m[9].setMonsterType("bloody");
//
//        // output some attributes with getters
//        System.out.println(m[0].getMonsterType());
//        System.out.println(m[1].getClass());
//        System.out.println(m[4].getMonsterType());
//
//        // print out the array of objects
//        for (int i = 0; i < m.length; i++) {
//            System.out.println(m[i].getMonsterType());
//        }
//
//
//
//    }
//}

// ZOMBIE SIM Non OOP
//import java.lang.*;
//
//public class Main {
//
//    public static void main(String[] args) {
//        // char zWorld[][] = createWorld();
//        char zWorld[][] = new char[10][10];
//        int x = 2, y = 2;       //coordinates of Patient Zero
//
//        populate(zWorld, 0.1);       //fill array with a period character '.'
//        outputWorld(zWorld);    //print the matrix
//        infect(zWorld, x, y);   //place a zombie 'Z' at the location of Patient Zero
//
//        // returns the current value of the system timer, in nanoseconds
//        System.out.print("time in nanoseconds = ");
//        System.out.println(System.nanoTime());
//
//    }
//
//
//    // write methods for createWorld, populate, outputWorld
//    public static char[][] createWorld(int size) {
//        char [][] A = new char[size][size];
//        return A;
//    }
//
//    public static void populate(char [][]B, double immunityRate) {
//        for (int i = 0; i < B.length; ++i) {
//            for(int j = 0; j < B[i].length; ++j) {
//                double p = Math.random();
//                if (0 <= p && p <= immunityRate) {
//                    B[i][j] = 'i';
//                }
//                else {
//                    B[i][j] = '.';
//                }
//            }
//        }
//    }
//
//    public static void outputWorld(char[][]C) {
//        for (int i = 0; i < C.length; ++i) {
//            for(int j = 0; j < C[i].length; ++j) {
//                System.out.print(C[i][j]);
//            }
//            System.out.println();
//        }
//    }
//
//
//    public static void infect(char matrix[][], int x, int y) {
//        //method to check the nearest neighbors of a given cell, then move "out"
//        int row = 0, col = 0;
//        int numIterations = 1;
//
//        //int maxIterations = calculateNumIterations(sRow, sCol);
//        int maxIterations = matrix.length - 1;  // can be changed for efficiency
//
//        // initialize counter for out of bounds exception
//        int numExceptions = 0;
//        int loopCount = 0;
//
//        matrix[x][y] = 'Z';    // these two lines are not necessary for logic but
//        outputWorld(matrix);   // print the Patient Zero matrix
//
//        while (numIterations <= maxIterations) {
//            for (row = x - numIterations; row <= x + numIterations; row++) {
//                for (col = y - numIterations; col <= y + numIterations; col++) {
//                    try {
//                        if ((row >= 0) && (col >= 0) && (row < matrix.length) && (col < matrix[row].length)) {
//                            if (matrix[row][col] == '.') {
//                                matrix[row][col] = 'Z';
//                            }
//                        }
//                        loopCount++;
//                    }
//                    catch (IndexOutOfBoundsException ex) {
//                        //do nothing, just keep running
//                        //this method, as written, goes out of bounds a lot
//                        numExceptions++;
//                    }
//                }
//            }
//            numIterations++;
//            outputWorld(matrix);
//        }
//        //print number of times infect loop ran and number of times the out of bounds exception
//        System.out.println("infect loop ran " + loopCount + " times.");
//        System.out.println("Out of bounds exception thrown " + numExceptions + " times.");
//    }
//
//
//}  //end class
//
