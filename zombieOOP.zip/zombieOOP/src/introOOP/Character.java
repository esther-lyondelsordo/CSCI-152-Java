package introOOP;

public class Character {
    //constructors
    char [][] A = new char[size][size];
    for (int i = 0; i < A.length; ++i) {
            for(int j = 0; j < A[i].length; ++j) {
                System.out.print(A[i][j]);
            }
            System.out.println();
        }

    // setters
    // getters
}
