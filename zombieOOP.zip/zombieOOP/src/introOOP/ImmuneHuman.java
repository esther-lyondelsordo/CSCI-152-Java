package introOOP;

public class ImmuneHuman extends Character {
    //constructors
    char [][] B = new char[size][size];
    for (int i = 0; i < B.length; ++i) {
            for(int j = 0; j < B[i].length; ++j) {
                double p = Math.random();
                if (0 <= p && p <= immunityRate) {
                    B[i][j] = 'i';
                }
            }
        }


    // setters
    // getters
}
