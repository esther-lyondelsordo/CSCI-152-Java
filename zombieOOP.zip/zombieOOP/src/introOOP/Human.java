package introOOP;

public class Human extends Character {
    // constructors
    char [][] B = new char[size][size];
    for (int i = 0; i < B.length; ++i) {
        for(int j = 0; j < B[i].length; ++j) {
            B[i][j] = '.';
        }
    }

    // setters
    // getters
}
