public class Zombie extends Monster {

    private boolean walking = true;

    Zombie() {
        this.monsterType = "devouring";
        System.out.println("A zombie was created.");
    }

    public boolean isWalking() {
        return walking;
    }

    public void setWalking(boolean walking) {
        this.walking = walking;
    }
}