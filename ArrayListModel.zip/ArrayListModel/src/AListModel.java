public class AListModel {
}
