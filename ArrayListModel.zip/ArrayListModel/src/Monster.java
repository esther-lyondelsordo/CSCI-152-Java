public class Monster  {
    boolean scary = true;
    String monsterType = "nocturnal";

    // setters
    public void setScary(boolean newValue)  {
        this.scary = newValue;
    }

    public void setMonsterType(String newType) {
        this.monsterType = newType;
    }

    //getters
    public boolean isScary()  {
        return this.scary;
    }

    public String getMonsterType()  {
        return this.monsterType;
    }
}
