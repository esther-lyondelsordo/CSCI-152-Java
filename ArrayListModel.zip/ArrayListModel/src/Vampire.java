public class Vampire extends Monster {
    private boolean hungry = true;

    //Constructors
    Vampire() {
        this.monsterType = "biting";
        System.out.println("A vampire was created.");
    }

    // write setters and getters
    public boolean isHungry() {
        return hungry;
    }

    public void setHungry(boolean hungry) {
        this.hungry = hungry;
    }

}
