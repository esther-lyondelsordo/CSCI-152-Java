public class Werewolf extends Monster {

    private boolean fullmoon = true;

    Werewolf() {
        this.monsterType = "biting";
        System.out.println("A werewolf was created.");
    }

    public boolean isFullmoon() {
        return fullmoon;
    }

    public void setFullmoon(boolean fullmoon) {
        this.fullmoon = fullmoon;
    }
}